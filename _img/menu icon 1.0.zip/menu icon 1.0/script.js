$(document).ready(function(){
	$('.menu').click(function(){
		$('.menu').toggleClass('active');
	});
});